=== Plugin Name ===
Contributors: wizcoder
Donate link: 
Tags: ecommerce
Requires at least: 4.5
Tested up to: 4.5.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A woocommerce extension to allow out of sotck products to have a waiting list for registered and non-registered users.

== Description ==

Add a waiting list email box for non-registered users for out-of-stock
Add join waiting list button for all registered users
Automatically email waiting list when stock status is set to in-stock
A waiting list page to list all product and the number of people on waiting list
A dashboard widget display the total product that have a waiting list


== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress

== Frequently Asked Questions ==
.


== Screenshots ==
.


== Changelog ==
.

== Upgrade Notice ==
NO Upgrade

== Arbitrary section ==
.

== A brief Markdown Example ==