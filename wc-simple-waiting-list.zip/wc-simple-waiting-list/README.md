# wc-simple-waiting-list
A woocommerce extension to allow out of stock products to have a waiting list for registered and non-registered users.
